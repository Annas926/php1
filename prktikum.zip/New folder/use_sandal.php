<?php 
require_once 'class_sandal.php';

$sandal = new Sandal();
$sepatu = new Sandal();

$sandal->set_name('sandal');
$sandal->set_color('ijo');
$sepatu->set_name('sepatu');
$sepatu->set_color('item');

echo ' punya '.$sandal->get_name().' warnanya '.$sandal->get_color();
echo '<br/>punya '.$sepatu->get_name().' warnanya '.$sepatu->get_color();
?>