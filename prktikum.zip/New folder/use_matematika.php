<?php
// tangkap request class_matematika.php
require_once 'class_matematika.php' ;

// akses static member variable class matematika 
Matematika::$counter++;
Matematika::$counter++;
Matematika::naikanCounter();
echo 'Counter sekarang : '. Matematika::$counter;
echo '<hr/>';
 
// akses static member function class matematika 
$x = Matematika :: tambahkan (4,5);
echo "4 + 5 = $x";
echo '<hr/>';
 
// akses constanta class matematika 
echo 'Nilai PHI : '. Matematika::PHI;
$luas_lingkaran = Matematika::luaslingkaran(8);
echo '</br>luas lingkaran dengan jari-jari 8 adalah : '. $luas_lingkaran;
echo '<hr/>';

$x = Matematika :: tambahkan (35,15);
echo "35 - 15 = $x";
echo '<hr/>';
?>